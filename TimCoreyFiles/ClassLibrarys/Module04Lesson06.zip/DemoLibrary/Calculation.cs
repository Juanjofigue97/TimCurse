﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoLibrary
{
    public static class Calculation
    {
        public static double Add(double x, double y)
        {
            double output = 0;

            output = x + y;

            return output;
        }
    }
}
