﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RPDemoApp.Models
{
    public class OrderUpdateModel
    {
        public int Id { get; set; }
        public string OrderName { get; set; }
    }
}
