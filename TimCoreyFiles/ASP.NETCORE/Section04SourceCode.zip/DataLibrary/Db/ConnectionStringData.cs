﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLibrary.Db
{
    public class ConnectionStringData
    {
        public string SqlConnectionName { get; set; } = "Default";
    }
}
