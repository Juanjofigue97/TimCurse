﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLibrary.Models
{
    public class IdLookupModel
    {
        public int Id { get; set; }
    }
}
