﻿CREATE TABLE [dbo].[PhoneNumbers]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [PhoneNumber] VARCHAR(20) NOT NULL
)
