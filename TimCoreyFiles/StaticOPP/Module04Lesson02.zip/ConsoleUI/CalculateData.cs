﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public static class CalculateData
    {
        public static double Add(double x, double y)
        {
            double output = x + y;

            return output;
        }
    }
}
