﻿using System;
using System.Collections.Generic;
using ConsoleUI.Models;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            List<PersonModel> people = new List<PersonModel>();
            Console.WriteLine();

            PersonModel person = new PersonModel();

            Calculations.Add(4, 3);

            Console.ReadLine();
        }
    }
}
