﻿namespace CardGame
{
    public class PlayingCardModel
    {
        public CardSuit Suit { get; set; }
        public CardValue Value { get; set; }
    }
}
