﻿
// true or false

bool isComplete = true;

//isComplete = !isComplete;

Console.WriteLine(!isComplete);
Console.WriteLine(isComplete);