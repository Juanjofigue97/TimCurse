﻿namespace DemoLibrary
{
    public class DataAccess
    {
        protected internal string GetConnectionString()
        {
            return "Sensitive data";
        }
    }
}
