﻿namespace DemoLibrary
{
    public class Employee : Person
    {
        public string GetFormerLastName()
        {
            return formerLastName;
        }
    }
}
