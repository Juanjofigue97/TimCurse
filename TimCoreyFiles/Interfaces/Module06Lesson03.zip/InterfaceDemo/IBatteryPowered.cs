﻿namespace InterfaceDemo
{
    public interface IBatteryPowered
    {
        int BatteryLevel { get; set; }
    }
}
