﻿namespace InterfaceDemo
{
    public class Keyboard : IComputerController
    {
        public void Connect()
        {

        }

        public void CurrentKeyPressed()
        {

        }

        public void Dispose()
        {
        }

        public string ConnectionType { get; set; }
    }
}
