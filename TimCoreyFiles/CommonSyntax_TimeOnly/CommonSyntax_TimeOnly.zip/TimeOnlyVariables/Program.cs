﻿

TimeOnly opensAt = TimeOnly.Parse("8:00 AM");

TimeOnly rightNow = TimeOnly.FromDateTime(DateTime.Now);

Console.WriteLine(opensAt);
Console.WriteLine(rightNow);