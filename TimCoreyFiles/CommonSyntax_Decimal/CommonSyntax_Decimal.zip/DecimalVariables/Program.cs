﻿

// 4.12, 32, 1.234
// 4.12, 32, 1.234

// Int32 - 00000000 00000000 00000000 00000001

decimal bankAccountBalance;

bankAccountBalance = 2.34M;

Console.WriteLine(bankAccountBalance);