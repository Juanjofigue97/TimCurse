﻿namespace InheritanceMiniProject
{
    public interface IPurchasable : IInventoryItem
    {
        void Purchase();
    }
}
