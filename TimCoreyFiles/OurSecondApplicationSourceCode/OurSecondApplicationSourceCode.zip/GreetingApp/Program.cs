﻿

// Welcome User To App
Console.WriteLine("Welcome to the Greeting Application");
Console.WriteLine("This application was built by Tim Corey");
Console.WriteLine("---------------------------------------");
Console.WriteLine();

// Ask for First Name
Console.Write("What is your first name: ");
string firstName;
firstName = Console.ReadLine();

// Greet user by name
Console.WriteLine();
Console.WriteLine("Hello " + firstName);

Console.WriteLine("Thank you for using my application.");
Console.ReadLine();