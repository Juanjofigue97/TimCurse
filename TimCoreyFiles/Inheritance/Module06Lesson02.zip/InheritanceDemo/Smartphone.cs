﻿using System.Collections.Generic;

namespace InheritanceDemo
{
    public class Smartphone : Cellphone
    {
        public List<string> Apps { get; set; }
        
        public void ConnectToInternet()
        {

        }
    }
}
