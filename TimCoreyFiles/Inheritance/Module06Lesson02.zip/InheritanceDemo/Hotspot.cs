﻿namespace InheritanceDemo
{
    public class Hotspot
    {

    }
}
