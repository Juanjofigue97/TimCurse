﻿namespace InheritanceDemo
{
    public class Cellphone : Phone
    {
        public string Carrier { get; set; }

    }
}
