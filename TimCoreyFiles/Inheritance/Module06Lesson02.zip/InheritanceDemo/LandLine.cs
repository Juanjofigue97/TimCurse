﻿namespace InheritanceDemo
{
    public class LandLine : Phone
    {

    }
}
