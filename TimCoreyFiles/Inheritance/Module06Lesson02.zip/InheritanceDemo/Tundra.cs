﻿namespace InheritanceDemo
{
    public class Tundra
    {

    }
}
