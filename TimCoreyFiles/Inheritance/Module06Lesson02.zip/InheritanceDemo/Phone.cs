﻿namespace InheritanceDemo
{
    public class Phone
    {
        public void PlaceCall()
        {

        }

        public void EndCall()
        {

        }
    }
}
