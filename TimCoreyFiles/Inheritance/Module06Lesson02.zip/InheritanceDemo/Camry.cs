﻿namespace InheritanceDemo
{
    // A Camry is a Car
    public class Camry : Car
    {

    }
}
