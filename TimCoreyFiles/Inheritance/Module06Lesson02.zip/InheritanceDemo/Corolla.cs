﻿namespace InheritanceDemo
{
    // A Corolla is a Car
    public class Corolla : Car
    {
        
    }
}
