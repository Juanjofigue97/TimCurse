﻿namespace InheritanceDemo
{
    public class Car
    {
        public int NumberOfWheels { get; set; }
        public int NumberOfDoors { get; set; }

        public void StartCar()
        {

        }

        public void StopCar()
        {

        }
    }
}
