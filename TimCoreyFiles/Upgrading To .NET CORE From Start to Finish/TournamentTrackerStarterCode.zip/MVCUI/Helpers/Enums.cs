﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCUI
{
    public enum RoundStatus
    {
        Active,
        Locked,
        Complete
    }
}