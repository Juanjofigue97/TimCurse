﻿namespace AbstractClassDemo
{
    public class Book : InventoryItem
    {

    }
}
