﻿namespace AbstractClassDemo
{
    public abstract class InventoryItem
    {
        public string ProductName { get; set; }
        public int QuantityOnHand { get; set; }
    }
}
