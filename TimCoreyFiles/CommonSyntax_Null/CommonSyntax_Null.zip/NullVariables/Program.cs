﻿

// null - lack of value

// Haven't asked for the age yet
int? age = null;
bool? birthday = null;
double? battingAverage = null;
decimal? accountBalance = null;
string? firstName = null;

// We have asked for the age now
age = 0;