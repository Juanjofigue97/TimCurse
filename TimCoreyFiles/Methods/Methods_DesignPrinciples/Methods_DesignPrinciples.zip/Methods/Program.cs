﻿using Methods;

//for (int i = 0; i < 10; i++)
//{
//    SampleMethods.SayHi();
//}

// DRY - Don't Repeat Yourself
// SOLID - SRP - Single Responsibility Principle

ConsoleMessages.SayHi();

Console.WriteLine("This is Tim");

ConsoleMessages.SayGoodbye();