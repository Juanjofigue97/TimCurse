﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methods
{
    public static class SampleMethods
    {
        public static void SayHi()
        {
            Console.WriteLine("Hello User");
        }
    }
}
