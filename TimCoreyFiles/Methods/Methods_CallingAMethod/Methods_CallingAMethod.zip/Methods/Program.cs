﻿using Methods;

//for (int i = 0; i < 10; i++)
//{
//    SampleMethods.SayHi();
//}

ConsoleMessages.SayHi();

Console.WriteLine("This is Tim");

ConsoleMessages.SayHi();