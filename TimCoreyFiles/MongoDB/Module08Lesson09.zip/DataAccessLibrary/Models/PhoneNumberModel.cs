﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLibrary.Models
{
    public class PhoneNumberModel
    {
        public string PhoneNumber { get; set; }
    }
}
