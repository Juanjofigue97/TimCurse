﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLibrary.Models
{
    public class EmailAddressModel
    {
        public string EmailAddress { get; set; }
    }
}
