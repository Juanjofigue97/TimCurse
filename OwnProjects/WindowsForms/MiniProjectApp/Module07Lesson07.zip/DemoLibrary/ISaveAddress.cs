﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoLibrary
{
    public interface ISaveAddress
    {
        void SaveAddress(AddressModel address);
    }
}
